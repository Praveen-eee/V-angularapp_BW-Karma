import { Component } from '@angular/core';



@Component({
  selector: 'app-add-theme',
  templateUrl: './addtheme.component.html',
  styleUrls: ['./addtheme.component.css']
})

  export class AddThemeComponent {

 
      constructor(){
    
      }

      ngOnInit(): void{

      }

    
    }
    