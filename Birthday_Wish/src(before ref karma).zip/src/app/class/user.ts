export class User {
    // userId         ?:number;
    email    !:String;
    password   !:String;
    mobileNumber !:String;
    username !:String;
    userRole !:String;
}
