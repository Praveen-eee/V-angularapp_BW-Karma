export class Theme{
themeId  : number = 0;  
themePhotographer!:String;
themeReturnGift!:String;
themeName!:String;
themeImageURL !:String;
themeVideographer !:String;
themeCost !:number;
themeDescription !:String;
}